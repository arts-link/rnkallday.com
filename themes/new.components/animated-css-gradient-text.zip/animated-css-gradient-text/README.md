# Animated CSS Gradient Text

A Pen created on CodePen.

Original URL: [https://codepen.io/argyleink/pen/vEBmZNw](https://codepen.io/argyleink/pen/vEBmZNw).

