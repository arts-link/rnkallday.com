# Portfolio navigation with VFX-JS

A Pen created on CodePen.

Original URL: [https://codepen.io/jdillon/pen/LEYJYYK](https://codepen.io/jdillon/pen/LEYJYYK).

