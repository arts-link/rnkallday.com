# slider-point ani css only

A Pen created on CodePen.

Original URL: [https://codepen.io/uchardon/pen/zxYVPjO](https://codepen.io/uchardon/pen/zxYVPjO).

