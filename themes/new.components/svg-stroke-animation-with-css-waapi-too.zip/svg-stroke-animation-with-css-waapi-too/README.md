# SVG Stroke Animation with CSS (WAAPI Too)

A Pen created on CodePen.

Original URL: [https://codepen.io/HejChristian/pen/GgRaEBx](https://codepen.io/HejChristian/pen/GgRaEBx).

Expanding upon my previous attempt at this, turns out we can do it with --just-- CSS! (For browsers that support it) I also left a basic WAAPI implemention commented out in the JS, as it achieves the same effect using native CSS animations, but can unlock so much more. 